# RoboMasterCode
RoboMaster Embeded System Code for STM32F427IIX on Hero Robotics
