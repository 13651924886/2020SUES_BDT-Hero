#ifndef __GM6020_PWM_H__
#define __GM6020_PWM_H__

#include "stm32f4xx.h"


extern void GM6020_PWM_configuration(void);



#endif


