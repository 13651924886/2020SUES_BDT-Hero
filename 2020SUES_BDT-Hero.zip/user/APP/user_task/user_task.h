#ifndef USER_TASK_H
#define USER_TASK_H

extern void UserTask_Setup(void);
extern void UserTask(void);

#endif
